from django.contrib import admin

from Home.models import Products

# Register your models here.
@admin.register(Products)
class UserAdmin(admin.ModelAdmin):
    # admin.site.register(myuser_Address)
    list_display=['name']
    list_filter=['name']
    search_fields=['name','id']