from django import forms
from django.db.models import fields
from Home.models import *


class Category_Form(forms.ModelForm):
    class Meta:
        model = Category
        fields='__all__'
class Brand_Form(forms.ModelForm):
    class Meta:
        model = Brand
        fields='__all__'
class Products_Form(forms.ModelForm):
    class Meta:
        model = Products
        fields='__all__'
class Order_Form(forms.ModelForm):
    class Meta:
        model = Order
        fields='__all__'
class Cart_Form(forms.ModelForm):
    class Meta:
        model = Cart
        fields='__all__'
class OTP_Form(forms.ModelForm):
    class Meta:
        model = OTP
        fields='__all__'
class Order_details_Form(forms.ModelForm):
    class Meta:
        model = Order_details
        fields='__all__'


class ContactUs_Form(forms.ModelForm):
    class Meta:
        model = ContactUs
        fields='__all__'