from django.contrib import admin
from django.contrib.admin.decorators import register
from User.models import *
# Register your models here.

@admin.register(myuser)
class UserAdmin(admin.ModelAdmin):
    # admin.site.register(myuser_Address)
    list_display=['name','mobile_no','email_id']
    list_filter=['name']
    search_fields=['name','id','email_id']

@admin.register(myuser_Address)
class address_myuserAdmin(admin.ModelAdmin):
    list_display=['myuser','city','id']
    list_filter=["id",'myuser']
    search_fields = ["id",'myuser']