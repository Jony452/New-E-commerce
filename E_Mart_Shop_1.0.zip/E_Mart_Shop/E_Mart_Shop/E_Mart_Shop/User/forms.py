from django import forms
from .models import *

class myuserForm(forms.ModelForm):
    class Meta:
        model = myuser
        exclude = ['user']