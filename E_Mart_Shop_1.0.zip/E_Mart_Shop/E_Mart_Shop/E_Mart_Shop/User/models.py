from django.db import models
from django.contrib.auth.models import User

# Create your models here.


class myuser(models.Model):
    name = models.CharField(max_length=50)
    email_id = models.CharField(max_length=50)
    mobile_no = models.CharField( max_length=50)
    photo = models.ImageField(upload_to='User/img',null=True,blank=True,max_length=120)
    user = models.OneToOneField(User,on_delete=models.CASCADE)
    user_type =models.CharField( max_length=50,choices=[('buyer','Buyer'),('seller','Seller')],default='buyer')
    user_status = models.CharField(max_length=50)

    def __str__(self) :
        # return str(self.id)
        return str(self.name)

class myuser_Address(models.Model):
    city = models.CharField(max_length=50)
    state = models.CharField(max_length=50)
    country = models.CharField(max_length=50)
    pin_code = models.TextField()
    myuser=models.ForeignKey(myuser,on_delete=models.CASCADE)

    def __str__(self):
        return str(self.myuser)
    
