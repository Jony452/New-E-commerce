from django.urls import path
from .views import *

urlpatterns = [
    path('', homeView,name='home'),
    path('category/', category_View,name='category'),
    path('brand/', brand_View,name='brand'),
    path('item/', item_View,name='item'),
    path('products/', products_View,name='products'),
    path('order/', order_View,name='order'),
    path('orderdetails/', order_details_View,name='otp'),
    path('otp/', otpView,name='otp'),
    path('cart/', cart_View,name='cart'),

]
