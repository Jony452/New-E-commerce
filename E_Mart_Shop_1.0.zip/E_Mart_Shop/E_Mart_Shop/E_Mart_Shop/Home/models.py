from typing import Sized
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.db import models

from User.models import myuser

# Create your models here.

def quantity_validator(value):
    if value >=10 :
        raise ValidationError("You can only purchase 10 items at a time")

class Category(models.Model):
    name = models.CharField(max_length=50)
    status = models.CharField(max_length=50)
    photo = models.ImageField(upload_to='Home/Category',null=True,blank=True)

class Brand(models.Model):
    name = models.CharField(max_length=50)
    status = models.CharField(max_length=50)
    photo = models.ImageField(upload_to='Home/Brand',null=True,blank=True)

class Products(models.Model):
    name = models.CharField(max_length=50)
    photo = models.ImageField(upload_to='Home/Category',null=True,blank=True)
    actual_price = models.IntegerField(default=0)
    selling_price = models.IntegerField(default=0)
    myuser=models.ForeignKey(myuser, on_delete=models.CASCADE)
    Category=models.ForeignKey(Category, on_delete=models.CASCADE)
    Brand=models.ForeignKey(Brand, on_delete=models.CASCADE)

class OTP(models.Model):
    reference_no = models.CharField(max_length=100,unique=True)
    otp=models.IntegerField()
    creation_time=models.DateTimeField(auto_now_add=True)
    is_issued = models.BooleanField(null=True)

class Order(models.Model):
    creation_date = models.DateTimeField(auto_now_add=True)
    myuser = models.ForeignKey(myuser, on_delete=models.CASCADE)
    order_status = models.CharField( max_length=50)

class Order_details(models.Model):
    Order = models.ForeignKey(Order, on_delete=models.CASCADE)
    Products = models.ForeignKey(Products, on_delete=models.CASCADE)
    quantity=models.IntegerField(validators=[quantity_validator])
    actual_price = models.IntegerField(default=0)
    selling_price = models.IntegerField(default=0)
    discount = models.IntegerField(default=0)
    actual_paid_amount=models.IntegerField(default=0)

class Cart(models.Model):
    Products = models.ForeignKey(Products, on_delete=models.CASCADE)
    creation_date = models.DateTimeField(auto_now_add=True)
    product_status = models.CharField( max_length=50)
    User=models.OneToOneField(User, on_delete=models.CASCADE)