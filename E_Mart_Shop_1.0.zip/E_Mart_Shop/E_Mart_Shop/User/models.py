from django.db import models
from django.contrib.auth.models import User

# Create your models here.


class myuser(models.Model):
    email_id = models.CharField(max_length=50)
    user = models.OneToOneField(User,on_delete=models.CASCADE)
    def __str__(self) :
        # return str(self.id)
        return str(self.name)

class myuser_Address(models.Model):
    city = models.CharField(max_length=50)
    state = models.CharField(max_length=50)
    country = models.CharField(max_length=50)
    pin_code = models.TextField()
    myuser=models.ForeignKey(myuser,on_delete=models.CASCADE)

    def __str__(self):
        return str(self.myuser)
    
