from django.shortcuts import render

def login_not_required(func):
    def inner(r):
        if r.user.is_authenticated==False:
            return func(r)
        else:
            return render (r, "User/user.html")
    return inner